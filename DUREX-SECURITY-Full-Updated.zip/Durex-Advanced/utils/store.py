"""Small SQLite persistence layer for Durex Security (stdlib only)."""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / 'data' / 'durex.sqlite3'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def connect():
    db = sqlite3.connect(DB_PATH)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS guild_settings (guild_id INTEGER PRIMARY KEY, custom_prefix TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS extra_owners (guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, added_by INTEGER NOT NULL, PRIMARY KEY (guild_id, user_id))')
    db.execute('CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_json TEXT NOT NULL)')
    db.commit()
    return db

def get_prefix(guild_id):
    if not guild_id: return None
    with connect() as db:
        row = db.execute('SELECT custom_prefix FROM guild_settings WHERE guild_id=?', (guild_id,)).fetchone()
    return row[0] if row else None

def set_prefix(guild_id, prefix):
    with connect() as db:
        db.execute('INSERT INTO guild_settings(guild_id, custom_prefix) VALUES(?, ?) ON CONFLICT(guild_id) DO UPDATE SET custom_prefix=excluded.custom_prefix', (guild_id, prefix))

def list_extraowners(guild_id):
    with connect() as db:
        return [r[0] for r in db.execute('SELECT user_id FROM extra_owners WHERE guild_id=? ORDER BY user_id', (guild_id,)).fetchall()]

def add_extraowner(guild_id, user_id, added_by):
    with connect() as db:
        count = db.execute('SELECT COUNT(*) FROM extra_owners WHERE guild_id=?', (guild_id,)).fetchone()[0]
        exists = db.execute('SELECT 1 FROM extra_owners WHERE guild_id=? AND user_id=?', (guild_id, user_id)).fetchone()
        if exists: return 'exists'
        if count >= 5: return 'full'
        db.execute('INSERT INTO extra_owners(guild_id,user_id,added_by) VALUES(?,?,?)', (guild_id,user_id,added_by))
        return 'added'

def remove_extraowner(guild_id, user_id):
    with connect() as db:
        cur = db.execute('DELETE FROM extra_owners WHERE guild_id=? AND user_id=?', (guild_id,user_id))
        return cur.rowcount > 0

def load_state(key):
    with connect() as db:
        row = db.execute('SELECT state_json FROM app_state WHERE state_key=?', (key,)).fetchone()
    return row[0] if row else None

def save_state(key, value):
    with connect() as db:
        db.execute('INSERT INTO app_state(state_key,state_json) VALUES(?,?) ON CONFLICT(state_key) DO UPDATE SET state_json=excluded.state_json', (key,value))
