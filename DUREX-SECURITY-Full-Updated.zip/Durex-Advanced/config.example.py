"""Copy to config.py and fill in your own values. Never commit config.py."""
TOKEN = "PASTE_DISCORD_BOT_TOKEN_HERE"
PREFIX = "7"
OWNER_IDS = [123456789012345678]
EXTRA_OWNERS = []  # Up to five IDs; ignored while Anti-Betrayal is enabled
LOG_CHANNEL_ID = 0
JOIN_LEAVE_LOG_CHANNEL_ID = 0  # Optional separate join/leave log channel
WELCOME_CHANNEL_ID = 0
ANTI_SPAM_MESSAGES = 7
ANTI_SPAM_SECONDS = 7
MASS_BAN_THRESHOLD = 10
MASS_BAN_WINDOW_SECONDS = 15

STATUS = {"status": "dnd", "activity": "DUREX Safety | 7help"}
STREAM_URL = "https://twitch.tv/security"
