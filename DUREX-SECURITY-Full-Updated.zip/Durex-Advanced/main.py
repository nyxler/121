from pathlib import Path
import sys, subprocess
ROOT = Path(__file__).resolve().parent


def install_requirements():
    try:
        import discord  # noqa: F401
    except ImportError:
        print("Installing requirements...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")])


def main():
    # Generate the private local config from the public example after GitHub clone.
    config_path = ROOT / "config.py"
    if not config_path.exists():
        example = ROOT / "config.example.py"
        if example.exists():
            config_path.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
            print("Created config.py from config.example.py. Add your token, then run again.")
            raise SystemExit(0)
        print("Missing config.py and config.example.py.")
        raise SystemExit(2)
    install_requirements()
    import discord
    from discord.ext import commands
    import config

    token = str(getattr(config, "TOKEN", "")).strip()
    if not token or token == "PASTE_DISCORD_BOT_TOKEN_HERE":
        print("Open config.py and paste your Discord bot token into TOKEN.")
        raise SystemExit(2)
    from utils.store import get_prefix
    prefix = str(getattr(config, "PREFIX", "7") or "7")

    def dynamic_prefix(bot, message):
        custom = get_prefix(message.guild.id) if message.guild else None
        values = [prefix]
        if custom and custom not in values: values.append(custom)
        return commands.when_mentioned_or(*values)(bot, message)
    intents = discord.Intents.default()
    intents.guilds = True
    intents.members = True
    intents.message_content = True
    intents.moderation = True

    class DurexBot(commands.Bot):
        async def setup_hook(self):
            for ext in (
                "cogs.settings", "cogs.security", "cogs.moderation", "cogs.automod",
                "cogs.general", "cogs.welcome", "cogs.roles",
                "cogs.fun", "cogs.giveaways", "cogs.presence", "cogs.logging",
            ):
                try:
                    await self.load_extension(ext)
                    print(f"[LOAD] {ext}")
                except Exception as exc:
                    print(f"[ERROR] {ext}: {type(exc).__name__}: {exc}")
                    raise

    bot = DurexBot(command_prefix=dynamic_prefix, intents=intents,
                   help_command=None)

    @bot.event
    async def on_ready():
        print(f"DUREX SECURITY online as {bot.user} | guilds={len(bot.guilds)} | prefix={prefix}")
        try:
            await bot.tree.sync()
            print("[SYNC] Slash commands synced")
        except Exception as exc:
            print(f"[WARN] Slash sync failed: {exc}")
        print("Developed by Nyxler </>")
        print("Test in a private server first. Keep config.py private.")

    @bot.event
    async def on_command_error(ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            msg = "You don't have permission to use this command."
        elif isinstance(error, commands.BotMissingPermissions):
            msg = "I need more permissions to do that. Check my role position too."
        elif isinstance(error, commands.MissingRequiredArgument):
            msg = f"Missing argument: {error.param.name}."
        elif isinstance(error, commands.BadArgument):
            msg = "Invalid argument. Check the command format and member mention."
        elif isinstance(error, commands.CommandOnCooldown):
            msg = f"Try again in {error.retry_after:.1f}s."
        else:
            print(f"[COMMAND ERROR] {type(error).__name__}: {error!r}")
            msg = f"Command failed ({type(error).__name__}). Check the console."
        try:
            await ctx.reply(msg, mention_author=False, delete_after=10)
        except discord.HTTPException:
            pass

    bot.run(token, log_handler=None)

if __name__ == "__main__":
    main()
