import discord
from discord.ext import commands
from discord import app_commands
from utils.store import set_prefix, get_prefix, list_extraowners, add_extraowner, remove_extraowner

THEME = discord.Color.from_rgb(76, 110, 245)

class Settings(commands.Cog):
    def __init__(self, bot): self.bot = bot

    async def owner_check(self, ctx):
        if not ctx.guild or ctx.author.id != ctx.guild.owner_id:
            await ctx.reply('Only the actual server owner can change these settings.', mention_author=False, delete_after=10)
            return False
        return True

    @commands.command(name='customprefix', aliases=['setprefix'])
    @commands.guild_only()
    async def customprefix(self, ctx, prefix: str):
        if not await self.owner_check(ctx): return
        if not 1 <= len(prefix) <= 5 or any(ch.isspace() for ch in prefix):
            return await ctx.reply('Prefix must be 1–5 non-space characters.', mention_author=False)
        set_prefix(ctx.guild.id, prefix)
        await ctx.reply(f'Custom prefix saved: `{prefix}`. Global prefix `7` still works as fallback.', mention_author=False)

    @app_commands.command(name='customprefix', description='Set this server custom prefix (server owner only)')
    @app_commands.describe(prefix='A 1–5 character prefix')
    @app_commands.guild_only()
    async def slash_customprefix(self, interaction: discord.Interaction, prefix: str):
        if not interaction.guild or interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message('Only the actual server owner can change these settings.', ephemeral=True)
        if not 1 <= len(prefix) <= 5 or any(ch.isspace() for ch in prefix):
            return await interaction.response.send_message('Prefix must be 1–5 non-space characters.', ephemeral=True)
        set_prefix(interaction.guild.id, prefix)
        await interaction.response.send_message(f'Custom prefix saved: `{prefix}`. Global prefix `7` remains available.', ephemeral=True)

    @commands.group(name='extraowner', invoke_without_command=True)
    @commands.guild_only()
    async def extraowner(self, ctx):
        await ctx.reply(f'Use `{ctx.clean_prefix}extraowner add @member`, `remove @member`, or `list`. Maximum: 5 slots. Only the server owner can manage them.', mention_author=False)

    @extraowner.command(name='add')
    @commands.guild_only()
    async def extraowner_add(self, ctx, member: discord.Member):
        if not await self.owner_check(ctx): return
        if member.id == ctx.guild.owner_id or member.bot:
            return await ctx.reply('Choose a non-bot member who is not the server owner.', mention_author=False)
        result = add_extraowner(ctx.guild.id, member.id, ctx.author.id)
        messages = {'added': f'Added {member.mention} to ExtraOwner slots.', 'exists': 'That member is already an ExtraOwner.', 'full': 'All 5 ExtraOwner slots are occupied.'}
        await ctx.reply(messages[result], mention_author=False)

    @extraowner.command(name='remove')
    @commands.guild_only()
    async def extraowner_remove(self, ctx, member: discord.Member):
        if not await self.owner_check(ctx): return
        removed = remove_extraowner(ctx.guild.id, member.id)
        await ctx.reply('ExtraOwner removed.' if removed else 'That member was not in the ExtraOwner list.', mention_author=False)

    @extraowner.command(name='list')
    @commands.guild_only()
    async def extraowner_list(self, ctx):
        if not await self.owner_check(ctx): return
        ids = list_extraowners(ctx.guild.id)
        desc = '\n'.join(f'{i}. <@{uid}> (`{uid}`)' for i, uid in enumerate(ids, 1)) or 'No ExtraOwners configured.'
        e = discord.Embed(title='Durex Security | ExtraOwner Slots', description=desc, color=THEME)
        e.set_footer(text=f'{len(ids)}/5 slots used | Only server owner can manage')
        await ctx.reply(embed=e, mention_author=False)

    @app_commands.command(name='extraowners', description='List this server ExtraOwner slots (server owner only)')
    @app_commands.guild_only()
    async def slash_extraowners(self, interaction: discord.Interaction):
        if not interaction.guild or interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message('Only the actual server owner can view/manage these settings.', ephemeral=True)
        ids = list_extraowners(interaction.guild.id)
        desc = '\n'.join(f'{i}. <@{uid}> (`{uid}`)' for i, uid in enumerate(ids, 1)) or 'No ExtraOwners configured.'
        e = discord.Embed(title='Durex Security | ExtraOwner Slots', description=desc, color=THEME)
        e.set_footer(text=f'{len(ids)}/5 slots used')
        await interaction.response.send_message(embed=e, ephemeral=True)

async def setup(bot): await bot.add_cog(Settings(bot))
