import discord
from datetime import timedelta
from discord.ext import commands

THEME = discord.Color.from_rgb(76, 110, 245)

class Moderation(commands.Cog):
    def __init__(self, bot): self.bot = bot

    async def result(self, ctx, title, description, color=THEME, ephemeral=False):
        embed = discord.Embed(title=title, description=description[:3900], color=color, timestamp=discord.utils.utcnow())
        embed.set_footer(text="Durex Security | Moderation")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason="No reason provided"):
        if member.id == ctx.guild.owner_id or (member.top_role >= ctx.author.top_role and ctx.author.id != ctx.guild.owner_id):
            return await self.result(ctx, "Kick Failed", "Your role must be higher than the target's role.", discord.Color.red())
        await member.kick(reason=f"{ctx.author}: {reason}")
        await self.result(ctx, "Member Kicked", f"**Member:** {member.mention}\n**Moderator:** {ctx.author.mention}\n**Reason:** {reason}", discord.Color.orange())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason="No reason provided"):
        if member.id == ctx.guild.owner_id or (member.top_role >= ctx.author.top_role and ctx.author.id != ctx.guild.owner_id):
            return await self.result(ctx, "Ban Failed", "Your role must be higher than the target's role.", discord.Color.red())
        await member.ban(reason=f"{ctx.author}: {reason}")
        await self.result(ctx, "Member Banned", f"**Member:** {member.mention}\n**Moderator:** {ctx.author.mention}\n**Reason:** {reason}", discord.Color.red())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def timeout(self, ctx, member: discord.Member, minutes: int, *, reason="No reason provided"):
        if not 1 <= minutes <= 40320:
            return await self.result(ctx, "Invalid Duration", "Minutes must be between 1 and 40320.", discord.Color.red())
        if member.id == ctx.guild.owner_id or (member.top_role >= ctx.author.top_role and ctx.author.id != ctx.guild.owner_id):
            return await self.result(ctx, "Timeout Failed", "Your role must be higher than the target's role.", discord.Color.red())
        await member.timeout(discord.utils.utcnow() + timedelta(minutes=minutes), reason=f"{ctx.author}: {reason}")
        await self.result(ctx, "Member Timed Out", f"**Member:** {member.mention}\n**Duration:** {minutes} minute(s)\n**Reason:** {reason}", discord.Color.orange())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int, *, reason="No reason provided"):
        user = await self.bot.fetch_user(user_id)
        await ctx.guild.unban(user, reason=f"{ctx.author}: {reason}")
        await self.result(ctx, "Member Unbanned", f"**User:** {user}\n**Moderator:** {ctx.author.mention}\n**Reason:** {reason}", discord.Color.green())

    @commands.command(name="purge", aliases=["clear"])
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True, read_message_history=True)
    async def purge(self, ctx, amount: int):
        if not 1 <= amount <= 100:
            return await self.result(ctx, "Invalid Amount", "Choose an amount from 1 to 100.", discord.Color.red())
        deleted = await ctx.channel.purge(limit=amount + 1)
        await self.result(ctx, "Messages Purged", f"Deleted **{max(0, len(deleted)-1)}** message(s).", discord.Color.green())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def slowmode(self, ctx, seconds: int):
        if not 0 <= seconds <= 21600:
            return await self.result(ctx, "Invalid Slowmode", "Seconds must be between 0 and 21600.", discord.Color.red())
        await ctx.channel.edit(slowmode_delay=seconds)
        await self.result(ctx, "Slowmode Updated", f"Slowmode in {ctx.channel.mention} is now **{seconds}s**.", discord.Color.green())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def lockdown(self, ctx):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Lockdown by {ctx.author}")
        await self.result(ctx, "Channel Locked", f"{ctx.channel.mention} is locked for @everyone. Use `{ctx.clean_prefix}unlock` to reopen it.", discord.Color.orange())

    @commands.command()
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def unlock(self, ctx):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite, reason=f"Unlock by {ctx.author}")
        await self.result(ctx, "Channel Unlocked", f"{ctx.channel.mention} is unlocked.", discord.Color.green())

async def setup(bot): await bot.add_cog(Moderation(bot))
