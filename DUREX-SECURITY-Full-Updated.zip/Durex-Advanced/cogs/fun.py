import random
from discord.ext import commands

class Fun(commands.Cog):
    def __init__(self, bot): self.bot=bot
    @commands.command()
    async def coinflip(self, ctx): await ctx.reply(random.choice(["Heads", "Tails"]), mention_author=False)
    @commands.command(name="8ball")
    async def eightball(self, ctx, *, question):
        await ctx.reply(random.choice(["Yes.","No.","Probably.","Ask again later.","It is uncertain.","Very likely."]), mention_author=False)
    @commands.command()
    async def choose(self, ctx, *, options):
        items=[x.strip() for x in options.split("|") if x.strip()]
        if len(items)<2: return await ctx.reply("Format: `?choose option A | option B`", mention_author=False)
        await ctx.reply(f"Choice: **{random.choice(items)}**", mention_author=False)

async def setup(bot): await bot.add_cog(Fun(bot))
