import discord
from discord import app_commands
from discord.ext import commands

THEME = discord.Color.from_rgb(76, 110, 245)

EMOJI = {
    "tick": "<:ratio_tick:1487894048781111347>", "cross": "<:ratio_cross:1487894053080010803>",
    "developer": "<:ratioDeveloper:1487894058226683965>", "arrow": "<:ratio_arrow:1487894061594443788>",
    "dot": "<:ratioDeveloper:1487894058226683965>", "enabled": "<:ratio_enabled:1487894068594737163>",
    "disabled": "<:ratio_disabled:1487894072717742151>", "antinuke": "<:alerta:1487894082310246521>",
    "error": "<a:ratio_error:1488048323062534225>", "loading": "<a:loading:1488048325361139802>",
    "tick2": "<:ratio_tick2:1488048329463169106>", "enabled2": "<:ratio_enabled2:1488048333221265418>",
    "disabled2": "<:ratio_disabled2:1488048337562107934>", "automod": "<:automod:1488048340729073796>",
    "back": "<:ratio_back:1488048344633839617>", "invite": "<:inviteBtn:1461812701973053480>",
    "support": "<:supportBtn:1461812634167808091>",
}

HELP_MODULES = [
    ("Antinuke", "Antinuke settings and commands", "Security"),
    ("Antiraid", "Raid protection and join monitoring", "Security"),
    ("Security", "Anti-betrayal, whitelist and protected roles", "Security"),
    ("AutoMod", "Automated moderation settings", "AutoMod"),
    ("Automations", "Automation tools", "Utility"),
    ("Autoresponder", "Custom auto responses", "Utility"),
    ("CustomRole", "Custom role management", "Roles"),
    ("Fun", "Fun and entertainment commands", "Fun"),
    ("General", "General bot information", "General"),
    ("Giveaway", "Manage server giveaways", "Giveaways"),
    ("Leaderboard", "Server ranking and stats", "General"),
    ("Logging", "Audit logs and tracking", "Logging"),
    ("Moderation", "Moderation utilities", "Moderation"),
    ("Music", "Music playback controls", "Music"),
    ("Permit", "Permission management", "Settings"),
    ("ReactionRoles", "Self-assignable roles", "Roles"),
    ("Ticket", "Support ticket system", "Utility"),
    ("Utility", "Useful utility commands", "General"),
    ("Vanityroles", "Vanity role settings", "Roles"),
    ("Voice", "Voice channel controls", "Utility"),
    ("VoiceMaster", "Temporary voice channels", "Utility"),
    ("Welcomer", "Welcome messages setup", "Welcome"),
]

class HelpSelect(discord.ui.Select):
    def __init__(self, ctx):
        self.ctx = ctx
        options = [discord.SelectOption(label=n, value=n, description=d[:100]) for n, d, _ in HELP_MODULES]
        super().__init__(placeholder="Select Module From Here", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("This help menu belongs to the command user.", ephemeral=True)
        selected = self.values[0]
        cog_name = next((c for n, _, c in HELP_MODULES if n == selected), "General")
        cmds = []
        for cmd in self.ctx.bot.walk_commands():
            if cmd.hidden or cmd.parent is not None:
                continue
            if (cmd.cog_name or "General") == cog_name:
                cmds.append(f"`{self.ctx.clean_prefix}{cmd.qualified_name}` — {cmd.short_doc or 'No description provided.'}")
        descriptions = {
            "Antinuke": "`7antinuke setup`\n`7antinuke enable all`\n`7antinuke disable all`\n`7antinuke status`",
            "Antiraid": "Antiraid setup is included in `7antinuke setup`; review security logs and test in a private server.",
            "Security": "`7autosetup` · `7antinuke status` · `7antibetrayal status` · `7antinuke whitelist`",
            "Settings": "`/customprefix prefix:<value>` or `7customprefix <prefix>`; global prefix `7` always remains available.",
        }
        body = descriptions.get(selected) or "\n".join(cmds) or "This module is not implemented in the current Durex build yet."
        e = discord.Embed(title=f"DUREX SECURITY | {selected}", description=body, color=THEME, timestamp=discord.utils.utcnow())
        e.set_footer(text="Developed by Nyxler </>")
        await interaction.response.edit_message(embed=e, view=self.view)

class HelpView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.add_item(HelpSelect(ctx))

    @discord.ui.button(label="Main Menu", style=discord.ButtonStyle.primary)
    async def main_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("This help menu belongs to the command user.", ephemeral=True)
        await interaction.response.edit_message(embed=build_help_embed(self.ctx), view=self)

    @discord.ui.button(label="Antinuke Setup", style=discord.ButtonStyle.danger)
    async def setup_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("This help menu belongs to the command user.", ephemeral=True)
        e = discord.Embed(title="DUREX SECURITY | Antinuke Setup", description="Run `7antinuke setup` as the actual server owner. It creates/repairs the log channels, enables configured antinuke modules and creates the three Durex roles. Discord does not allow bots to make roles impossible for the server owner to edit.", color=THEME)
        e.set_footer(text="Developed by Nyxler </>")
        await interaction.response.edit_message(embed=e, view=self)

def build_help_embed(ctx):
    bot = ctx.bot
    security = bot.get_cog("Security")
    total = sum(1 for c in bot.walk_commands() if not c.hidden)
    e = discord.Embed(title="DUREX SECURITY", description=(
        "**Help Desk & Command Menu**\n"
        "Powerful server protection, antinuke monitoring and multipurpose tools.\n\n"
        f"{EMOJI['dot']} **Global Prefix:** `7`\n"
        f"{EMOJI['dot']} **Current Prefix:** `{ctx.clean_prefix}`\n"
        f"{EMOJI['dot']} **Commands:** `{total}`\n"
        "Choose a module from the dropdown below to explore commands."
    ), color=THEME, timestamp=discord.utils.utcnow())
    e.add_field(name=f"{EMOJI['antinuke']} Antinuke & Security", value="`7antinuke setup` · `7antinuke enable all` · `7antinuke status` · `7antibetrayal status`", inline=False)
    e.add_field(name=f"{EMOJI['enabled']} Protection Modules", value="AntiRole · AntiChannel · AntiWebhook · AntiBot · AntiKick · AntiBan · AntiGuild Update · AntiEmoji · AntiPrune", inline=False)
    e.add_field(name="Server Prefix", value="Global `7` always works. Set a server prefix with `/customprefix` or `7customprefix <prefix>`.", inline=False)
    if ctx.guild and security:
        vals = security.modules.get(ctx.guild.id, {})
        enabled = sum(bool(v) for v in vals.values())
        e.add_field(name="Protection Status", value=f"`{enabled}/{len(vals)}` antinuke modules enabled", inline=True)
    if bot.user:
        e.set_thumbnail(url=bot.user.display_avatar.url)
    e.set_footer(text="Developed by Nyxler </>")
    return e

class General(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="ping", description="Check Durex Security latency")
    async def slash_ping(self, interaction: discord.Interaction):
        e = discord.Embed(title="Durex Security | Latency", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Gateway latency", value=f"`{round(self.bot.latency * 1000)} ms`", inline=False)
        e.set_footer(text="Developed by Nyxler </>")
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="serverinfo", description="Show this server's information")
    @app_commands.guild_only()
    async def slash_serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        e = discord.Embed(title=f"{g.name} | Server Information", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Members", value=str(g.member_count or "Unknown"), inline=True)
        e.add_field(name="Roles", value=str(len(g.roles)), inline=True)
        e.add_field(name="Channels", value=str(len(g.channels)), inline=True)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>" if g.owner_id else "Unknown", inline=True)
        e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, style="D"), inline=True)
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.set_footer(text=f"Guild ID: {g.id} | Developed by Nyxler </>")
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="help", description="Open the Durex Security Help Desk")
    async def slash_help(self, interaction: discord.Interaction):
        e = discord.Embed(title="DUREX SECURITY | Help Desk", description="Use the `7help` command in a server channel to open the interactive dropdown menu. Global prefix: `7`; custom server prefix: `/customprefix`.", color=THEME, timestamp=discord.utils.utcnow())
        e.set_footer(text="Developed by Nyxler </>")
        await interaction.response.send_message(embed=e, ephemeral=True)

    @commands.command()
    async def ping(self, ctx):
        e = discord.Embed(title="Durex Security | Latency", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Gateway latency", value=f"`{round(self.bot.latency * 1000)} ms`", inline=False)
        e.set_footer(text="Durex Security")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command(name="help", aliases=["helpme", "commands", "helpdesk"])
    async def help_command(self, ctx):
        await ctx.reply(embed=build_help_embed(ctx), view=HelpView(ctx), mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        e = discord.Embed(title=f"{g.name} | Server Information", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Members", value=str(g.member_count or "Unknown"), inline=True)
        e.add_field(name="Roles", value=str(len(g.roles)), inline=True)
        e.add_field(name="Channels", value=str(len(g.channels)), inline=True)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>" if g.owner_id else "Unknown", inline=True)
        e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, style="D"), inline=True)
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.set_footer(text=f"Guild ID: {g.id}")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def userinfo(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = discord.Embed(title=f"User Information | {m}", color=THEME, timestamp=discord.utils.utcnow())
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="User ID", value=f"`{m.id}`", inline=False)
        e.add_field(name="Account created", value=discord.utils.format_dt(m.created_at, style="F"), inline=False)
        e.add_field(name="Joined server", value=discord.utils.format_dt(m.joined_at, style="F") if m.joined_at else "Unknown", inline=False)
        e.add_field(name="Top role", value=m.top_role.mention, inline=True)
        e.add_field(name="Bot account", value="Yes" if m.bot else "No", inline=True)
        roles = [r.mention for r in reversed(m.roles) if not r.is_default()]
        e.add_field(name=f"Roles ({len(roles)})", value=(" ".join(roles)[:1000] or "No roles"), inline=False)
        perms = [name.replace("_", " ").title() for name, value in m.guild_permissions if value]
        e.add_field(name="Server permissions", value=", ".join(perms)[:1000] or "No special permissions", inline=False)
        e.set_footer(text=f"Requested by {ctx.author}")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    async def avatar(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = discord.Embed(title=f"Avatar | {m}", color=THEME, timestamp=discord.utils.utcnow())
        e.set_image(url=m.display_avatar.url)
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def poll(self, ctx, *, question):
        parts = [p.strip() for p in question.split("|")]
        if len(parts) < 2:
            e = discord.Embed(title="Poll | Usage", description=f"`{ctx.clean_prefix}poll Question | Option A | Option B`", color=discord.Color.orange())
            return await ctx.reply(embed=e, mention_author=False)
        e = discord.Embed(title="Community Poll", description=parts[0], color=THEME, timestamp=discord.utils.utcnow())
        marks = ["🇦", "🇧", "🇨", "🇩", "🇪", "🇫", "🇬", "🇭", "🇮", "🇯"]
        for i, opt in enumerate(parts[1:11]): e.add_field(name=f"Option {marks[i]}", value=opt, inline=False)
        e.set_footer(text=f"Poll created by {ctx.author}")
        msg = await ctx.send(embed=e)
        for mark in marks[:min(10, len(parts) - 1)]:
            try: await msg.add_reaction(mark)
            except discord.HTTPException: break

async def setup(bot): await bot.add_cog(General(bot))
