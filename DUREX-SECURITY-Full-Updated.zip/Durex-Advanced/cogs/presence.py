import discord
from discord.ext import commands, tasks
import config

class Presence(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._presence.start()

    def cog_unload(self):
        self._presence.cancel()

    @tasks.loop(minutes=1)
    async def _presence(self):
        cfg = getattr(config, "STATUS", {}) or {}
        status_name = str(cfg.get("status", "dnd")).lower()
        status = {"online": discord.Status.online, "idle": discord.Status.idle, "dnd": discord.Status.dnd, "invisible": discord.Status.invisible}.get(status_name, discord.Status.dnd)
        activity_name = str(cfg.get("activity", "DUREX Safety | 7help"))
        stream_url = str(getattr(config, "STREAM_URL", "https://twitch.tv/security"))
        await self.bot.change_presence(status=status, activity=discord.Streaming(name=activity_name, url=stream_url))

    @_presence.before_loop
    async def before_presence(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(Presence(bot))
