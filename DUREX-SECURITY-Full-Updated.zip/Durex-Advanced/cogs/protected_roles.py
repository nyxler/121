"""Owner-only setup for DUREX's three roles. Discord role hierarchy still applies."""
import discord
from discord import app_commands
from discord.ext import commands
from utils.store import load_state, save_state
import json

ROLE_NAMES = ("Durex UnBypassable Force", "Durex Implated Here", "Power of Durex")
THEME = discord.Color.from_rgb(76, 110, 245)

class ProtectedRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        try: self.role_ids = {int(g): {str(n): int(r) for n, r in v.items()} for g, v in json.loads(load_state("protected_role_ids") or "{}").items()}
        except (ValueError, TypeError, json.JSONDecodeError): self.role_ids = {}

    def save(self):
        save_state("protected_role_ids", json.dumps({str(g): v for g, v in self.role_ids.items()}))

    async def setup_roles(self, guild):
        me = guild.me
        if not me or not me.guild_permissions.manage_roles:
            raise RuntimeError("Bot needs Manage Roles permission.")
        found = self.role_ids.setdefault(guild.id, {})
        roles = {}
        # Do not grant Administrator to the two security roles; role names do not make roles immutable.
        for name in ROLE_NAMES:
            role = guild.get_role(found.get(name, 0))
            if role is None:
                role = discord.utils.get(guild.roles, name=name)
            if role is None:
                role = await guild.create_role(name=name, permissions=discord.Permissions.none(), reason="DUREX SECURITY protected role setup")
            found[name] = role.id
            roles[name] = role
        self.save()
        # Place the two security roles and default role immediately below the bot's top role, if possible.
        ordered = [roles[n] for n in ROLE_NAMES]
        for role in ordered:
            if role >= me.top_role:
                continue
        try:
            positions = {role: max(1, me.top_role.position - (len(ordered) - i)) for i, role in enumerate(ordered)}
            await guild.edit_role_positions(positions=positions, reason="Keep DUREX roles grouped below bot role")
        except (discord.Forbidden, discord.HTTPException):
            pass
        # Backfill every cached human member. The Members intent must be enabled.
        default_role = roles["Power of Durex"]
        assigned, failed = 0, 0
        for member in guild.members:
            if member.bot or default_role in member.roles or default_role >= me.top_role:
                continue
            try:
                await member.add_roles(default_role, reason="DUREX default human member role")
                assigned += 1
            except (discord.Forbidden, discord.HTTPException):
                failed += 1
        return roles, assigned, failed

    @commands.command(name="rolesetup")
    @commands.guild_only()
    async def rolesetup(self, ctx):
        if ctx.author.id != ctx.guild.owner_id:
            return await ctx.reply(embed=discord.Embed(title="Permission denied", description="Only the actual server owner can run this setup.", color=discord.Color.red()), mention_author=False)
        try:
            roles, assigned, failed = await self.setup_roles(ctx.guild)
        except (RuntimeError, discord.Forbidden, discord.HTTPException) as exc:
            return await ctx.reply(embed=discord.Embed(title="Role setup failed", description=str(exc), color=discord.Color.red()), mention_author=False)
        e = discord.Embed(title="DUREX SECURITY | Role Setup", description="Created/verified the three roles with no permissions. Discord does not allow bots to make roles owner-proof.", color=THEME, timestamp=discord.utils.utcnow())
        for name, role in roles.items(): e.add_field(name=name, value=f"{role.mention}\nID: `{role.id}`", inline=False)
        e.add_field(name="Existing humans assigned", value=str(assigned), inline=True)
        e.add_field(name="Could not assign", value=str(failed), inline=True)
        e.set_footer(text="Developed by Nyxler </> | Bot needs Manage Roles and correct role hierarchy")
        await ctx.reply(embed=e, mention_author=False)

    @app_commands.command(name="rolesetup", description="Create DUREX roles and assign the default role (server owner only)")
    @app_commands.guild_only()
    async def slash_rolesetup(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild or interaction.user.id != guild.owner_id:
            return await interaction.response.send_message("Only the actual server owner can run this setup.", ephemeral=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            roles, assigned, failed = await self.setup_roles(guild)
        except (RuntimeError, discord.Forbidden, discord.HTTPException) as exc:
            return await interaction.followup.send(embed=discord.Embed(title="Role setup failed", description=str(exc), color=discord.Color.red()), ephemeral=True)
        e = discord.Embed(title="DUREX SECURITY | Role Setup", description="Three zero-permission roles created/verified. Roles cannot be made immutable against the server owner.", color=THEME)
        for name, role in roles.items(): e.add_field(name=name, value=f"{role.mention} (`{role.id}`)", inline=False)
        e.add_field(name="Existing humans assigned", value=str(assigned), inline=True)
        e.add_field(name="Could not assign", value=str(failed), inline=True)
        e.set_footer(text="Developed by Nyxler </>")
        await interaction.followup.send(embed=e, ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot: return
        role_id = self.role_ids.get(member.guild.id, {}).get("Power of Durex")
        role = member.guild.get_role(role_id or 0)
        me = member.guild.me
        if role and me and me.guild_permissions.manage_roles and role < me.top_role:
            try: await member.add_roles(role, reason="DUREX default human member role")
            except (discord.Forbidden, discord.HTTPException): pass

async def setup(bot): await bot.add_cog(ProtectedRoles(bot))
